
#ifndef NTL_vec_vec_long__H
#define NTL_vec_vec_long__H

#include <NTL/vec_long.h>

NTL_OPEN_NNS

typedef Vec< Vec<long> > vec_vec_long;

NTL_CLOSE_NNS


#endif
